$(window).load(function() {
	$('.preloader').fadeOut('slow');
});
$(document).ready(function(){
	$( function() {
		$( "#slider-range" ).slider({
	      range: true,
	      min: 0,
	      max: 500,
	      values: [ 75, 300 ],
	      slide: function( event, ui ) {
	        $( "#amount" ).val( "$" + ui.values[ 0 ] + " -  $" + ui.values[ 1 ] );
	      }
	    });
	    $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
	      " - $" + $( "#slider-range" ).slider( "values", 1 ) );
	});


	(function($){
        $(window).on("load",function(){
            $(".lss-cnt ul").mCustomScrollbar({
			    theme:"dark"
			});
		});
    })(jQuery);


	//new WOW().init();
	$('.suggestion-item-slider .owl-carousel').owlCarousel({
		loop:false,
		margin:0,
		items:5,
		nav:true,
		responsiveClass:true,
		responsive:{
			0:{
				items:1,
			},
			460:{
				items:2
			},
			767:{
				items:3
			},
			991:{
				items:4
			},
			1050:{
				items:5
			}
		}
	});
	$('.home-slider .owl-carousel').owlCarousel({
		loop:false,
		margin:0,
		items:1,
		nav:false,
		responsiveClass:true,
		responsive:{
			0:{
				items:1,
			},
			1200:{
				items:1
			}
		}
	});
	$('.sale-product .owl-carousel').owlCarousel({
		loop:false,
		margin:0,
		items:1,
		nav:true,
		responsiveClass:true,
		responsive:{
			0:{
				items:1,
			},
			1200:{
				items:1
			}
		}
	});
	$('.mobile-menu').click(function() {
        $('body').addClass('openMenu');
    });
	$('.overlay,.close-icon span').click(function() {
        $('body').removeClass('openMenu');
    });
    $('.foot-mid h4.mobile-head').click(function() {
    	$(this).parent('.fml-single').siblings().children('ul').slideUp();
        $(this).parent('.fml-single').children('ul').slideToggle();
    });
	
	$('.lss-head h3').click(function(event) {
		$(this).parents('.ls-single').children('.lss-cnt').slideToggle();
		$(this).parents('.ls-single').toggleClass('open')
	});
	$('.back-top a').click(function(event) {
		event.preventDefault();
		$('html, body').animate({scrollTop: 0}, 1000);
	});
	$('.choose-filter-mob').click(function(event) {
		$('body').addClass('open-filter')
	});
	$('.ls-btns .btn').click(function(event) {
		$('body').removeClass('open-filter')
	});


	function countryDropdown(seletor){
		var Selected = $(seletor);
		var Drop = $(seletor+'-drop');
		var DropItem = Drop.find('li');

		Selected.click(function(){
			Selected.toggleClass('open');
			Drop.toggle();
		});
		Drop.find('li').click(function(){
			Selected.removeClass('open');
			Drop.hide();
			var item = $(this);
			Selected.html(item.html());
		});
		DropItem.each(function(){
			var code = $(this).attr('data-code');
			if(code != undefined){
				var countryCode = code.toLowerCase();
				$(this).find('i').addClass('flagstrap-'+countryCode);
			}
		});
	}

	countryDropdown('#country');





});

$(document).ready(function() {
 
  $("#sug-slider").owlCarousel({
    navigation : false
  });
 
});

jQuery(window).scroll(function() {    
	var scroll = jQuery(window).scrollTop();
	if (scroll >= 37) {
		jQuery("body").addClass("sticky");
	} else {
		jQuery("body").removeClass("sticky");
	}
});

$(document).ready(function() {

  var sync1 = $("#sync1");
  var sync2 = $("#sync2");
  var slidesPerPage = 5; //globaly define number of elements per page
  var syncedSecondary = true;

  sync1.owlCarousel({
    items : 1,
    slideSpeed : 2000,
    nav: false,
    autoplay: false,
    dots: false,
    loop: false,
    responsiveRefreshRate : 200,
  }).on('changed.owl.carousel', syncPosition);

  sync2
    .on('initialized.owl.carousel', function () {
      sync2.find(".owl-item").eq(0).addClass("current");
    })
    .owlCarousel({
    items : slidesPerPage,
    dots: false,
    nav: false,
    smartSpeed: 200,
    slideSpeed : 500,
    slideBy: slidesPerPage, //alternatively you can slide by 1, this way the active slide will stick to the first item in the second carousel
    responsiveRefreshRate : 100
  }).on('changed.owl.carousel', syncPosition2);

  function syncPosition(el) {
    //if you set loop to false, you have to restore this next line
    //var current = el.item.index;
    
    //if you disable loop you have to comment this block
    var count = el.item.count-1;
    var current = Math.round(el.item.index - (el.item.count/2) - .5);
    
    if(current < 0) {
      current = count;
    }
    if(current > count) {
      current = 0;
    }
    
    //end block

    sync2
      .find(".owl-item")
      .removeClass("current")
      .eq(current)
      .addClass("current");
    var onscreen = sync2.find('.owl-item.active').length - 1;
    var start = sync2.find('.owl-item.active').first().index();
    var end = sync2.find('.owl-item.active').last().index();
    
    if (current > end) {
      sync2.data('owl.carousel').to(current, 100, true);
    }
    if (current < start) {
      sync2.data('owl.carousel').to(current - onscreen, 100, true);
    }
  }
  
  function syncPosition2(el) {
    if(syncedSecondary) {
      var number = el.item.index;
      sync1.data('owl.carousel').to(number, 100, true);
    }
  }
  
  sync2.on("click", ".owl-item", function(e){
    e.preventDefault();
    var number = $(this).index();
    sync1.data('owl.carousel').to(number, 300, true);
  });
});